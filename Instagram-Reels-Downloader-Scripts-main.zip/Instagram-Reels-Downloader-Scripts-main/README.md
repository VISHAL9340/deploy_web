# Instagram Reels Downloader PHP Script (Python script as a bonus)
Instagram Reels Downloader Script that allow you to download Instagram reels onto your computer/phone easily

# About the PHP version
Due to CORS policy, you cannot directly show Instagram images/video as embedded links but if you plan to download them locally and display them, that will work.

# Screenshot
<img src="https://raw.githubusercontent.com/TufayelLUS/Instagram-Reels-Downloader-Scripts/5b9058b0f32b800b842d9ef35ff5e63a053d8382/ss.png" />

# About the Python version
This allows you to insert Instagram reel links and save the video file directly onto your local folder. I'll add a usage guide later.
